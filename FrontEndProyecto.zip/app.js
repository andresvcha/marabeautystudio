document.addEventListener('DOMContentLoaded', () => {

    let appointments = [
        { id: 1, dateTime: new Date('2025-10-09T08:00:00'), state: 'reserved', client: { name: 'Ana Gomez', email: 'ana@mail.com'} },
        { id: 2, dateTime: new Date('2025-10-07T09:00:00'), state: 'available', client: null },
        { id: 3, dateTime: new Date('2025-10-09T10:00:00'), state: 'available', client: null },
        { id: 4, dateTime: new Date('2025-10-09T11:00:00'), state: 'available', client: null },
        { id: 5, dateTime: new Date('2025-10-09T12:00:00'), state: 'available', client: null },
        { id: 6, dateTime: new Date('2025-10-09T13:00:00'), state: 'available', client: null },
        { id: 7, dateTime: new Date('2025-10-09T014:00:00'), state: 'available', client: null },
        { id: 8, dateTime: new Date('2025-10-09T15:00:00'), state: 'available', client: null },
        { id: 9, dateTime: new Date('2025-10-09T16:00:00'), state: 'available', client: null },
        { id: 10, dateTime: new Date('2025-10-09T17:00:00'), state: 'available', client: null },
        { id: 11, dateTime: new Date('2025-10-09T18:00:00'), state: 'available', client: null },
        { id: 12, dateTime: new Date('2025-10-09T19:00:00'), state: 'available', client: null },
        { id: 13, dateTime: new Date('2025-10-10T12:00:00'), state: 'reserved', client: { name: 'Carlos Ruiz', email: 'carlos@mail.com'} },
        { id: 14, dateTime: new Date('2025-10-10T13:00:00'), state: 'reserved', client: { name: 'Carlos Ruiz', email: 'carlos@mail.com'} },
        { id: 15, dateTime: new Date('2025-10-11T12:00:00'), state: 'reserved', client: { name: 'Andres Velandia', email: 'andres@mail.com'} },
        { id: 16, dateTime: new Date('2025-10-12T12:00:00'), state: 'reserved', client: { name: 'Julian Mora', email: 'julian@mail.com'} },
        { id: 18, dateTime: new Date('2025-10-11T08:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-11T09:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-12T09:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-12T10:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-12T11:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-12T12:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-12T13:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-12T14:00:00'), state: 'available', client: null },
        { id: 2, dateTime: new Date('2025-10-12T15:00:00'), state: 'available', client: null },
    ];

    let selectedSlotInfo = null;
    let currentYear = 2025;
    let currentWeek = 41;
    const hours = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
    const locale = 'es-CO';
    const timeZone = 'America/Bogota';
    
    function getDateForWeek(year, week) {
        const d = new Date(year, 0, 1);
        const day = d.getDay();
        d.setDate(d.getDate() - day + (day === 0 ? -6 : 1) + (week - 1) * 7);
        d.setHours(0, 0, 0, 0);
        return d;
    }

    function updateNavButtons() {
        const prevBtn = document.getElementById('prev-week-btn');
        const nextBtn = document.getElementById('next-week-btn');
        if (prevBtn && nextBtn) {
            prevBtn.disabled = (currentWeek <= 1);
            nextBtn.disabled = (currentWeek >= 52);
        }
    }
    
    function populateTimeSelectors() {
        const startSelector = document.getElementById('new-time-start');
        const endSelector = document.getElementById('new-time-end');

        if (!startSelector || !endSelector) return;
        
        startSelector.innerHTML = '';
        endSelector.innerHTML = '';

        const placeholderOption = document.createElement('option');
        placeholderOption.value = "";
        placeholderOption.textContent = "HH:MM";
        placeholderOption.selected = true;
        placeholderOption.disabled = true;

        startSelector.appendChild(placeholderOption.cloneNode(true));
        endSelector.appendChild(placeholderOption.cloneNode(true));

        for (let i = 8; i <= 18; i++) {
            const hour = i.toString().padStart(2, '0') + ':00';
            startSelector.add(new Option(hour, hour));
        }
        
        for (let i = 8; i <= 19; i++) {
            const hour = i.toString().padStart(2, '0') + ':00';
            endSelector.add(new Option(hour, hour));
        }
    }

    function renderCalendar(containerId, isAdmin) {
        const calendarContainer = document.getElementById(containerId);
        if (!calendarContainer) return;

        const startOfWeek = getDateForWeek(currentYear, currentWeek);
        const weekDisplay = document.getElementById('week-display');
        if(weekDisplay) {
            weekDisplay.textContent = `Semana ${currentWeek} del ${currentYear}`;
        }

        const weekDays = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
        let html = '<div class="grid-header"></div>';
        for (let i = 0; i < 7; i++) {
            const day = new Date(startOfWeek);
            day.setDate(day.getDate() + i);
            html += `<div class="grid-header">${weekDays[i]}<br><span class="date-number">${day.getDate()}</span></div>`;
        }

        const now = new Date();

        hours.forEach(hour => {
            html += `<div class="time-label">${hour}</div>`;
            for (let dayIndex = 0; dayIndex < 7; dayIndex++) {
                const cellDate = new Date(startOfWeek);
                cellDate.setDate(startOfWeek.getDate() + dayIndex);
                const [h, m] = hour.split(':');
                cellDate.setHours(parseInt(h), parseInt(m), 0, 0);

                const appointment = appointments.find(a => a.dateTime.getTime() === cellDate.getTime());
                
                if (cellDate < now) {
                    if (appointment && appointment.state === 'reserved') {
                        const text = isAdmin ? `Reservada:<br>${appointment.client.name}` : 'RESERVADA';
                        html += `<div class="time-slot reserved" data-id="${appointment.id}">${text}</div>`;
                    } else {
                        html += `<div class="time-slot reserved"></div>`;
                    }
                } else {
                    if (appointment) {
                        const text = appointment.state === 'available' ? 'ABIERTO' : (isAdmin ? `Reservada:<br>${appointment.client.name}` : 'RESERVADA');
                        html += `<div class="time-slot ${appointment.state}" data-id="${appointment.id}">${text}</div>`;
                    } else {
                        html += `<div class="time-slot available-empty" data-datetime="${cellDate.toISOString()}"></div>`;
                    }
                }
            }
        });
        calendarContainer.innerHTML = html;
        addSlotEventListeners(containerId, isAdmin);
        updateNavButtons();
    }
    
    function addSlotEventListeners(containerId, isAdmin) {
        document.querySelectorAll(`#${containerId} .time-slot`).forEach(slot => {
            slot.addEventListener('click', () => {
                if (slot.classList.contains('reserved')) return;
                
                const wasSelected = slot.classList.contains('selected');
                document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
                
                selectedSlotInfo = null;

                if (!wasSelected) {
                    slot.classList.add('selected');
                    if (slot.dataset.id) {
                        selectedSlotInfo = { id: parseInt(slot.dataset.id), type: 'existing' };
                    } else if (slot.dataset.datetime) {
                        selectedSlotInfo = { datetime: slot.dataset.datetime, type: 'empty' };
                    }
                }
                
                const bookBtn = document.getElementById('book-action-btn');
                const deleteBtn = document.getElementById('show-delete-modal-btn');

                if (isAdmin) {
                    deleteBtn.disabled = !(selectedSlotInfo && selectedSlotInfo.type === 'existing');
                } else {
                    bookBtn.disabled = !(selectedSlotInfo && selectedSlotInfo.type === 'existing');
                }
            });
        });
    }

    function showAlert(message, type = 'info', context = 'client') {
        const container = document.getElementById(`alert-container-${context}`);
        if (!container) return;
        container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
        setTimeout(() => container.innerHTML = '', 4000);
    }

    function showModal(modalId) {
        const modal = document.getElementById(modalId);
        const formatOptions = {
            timeZone: timeZone,
            year: 'numeric', month: 'numeric', day: 'numeric',
            hour: '2-digit', minute: '2-digit', hour12: false
        };

        if (modalId === 'delete-modal' || modalId === 'book-modal' || modalId === 'cancel-modal') {
            if (!selectedSlotInfo || selectedSlotInfo.type !== 'existing') {
                showAlert('Por favor, selecciona una cita válida.', 'error', document.getElementById('admin-calendar') ? 'admin' : 'client');
                return;
            }
            const appointment = appointments.find(a => a.id === selectedSlotInfo.id);
            if (!appointment) {
                 showAlert('La cita seleccionada ya no existe.', 'error', document.getElementById('admin-calendar') ? 'admin' : 'client');
                 return;
            }

            if (modalId === 'delete-modal') document.getElementById('delete-cita-datetime').value = appointment.dateTime.toLocaleString(locale, formatOptions);
            if (modalId === 'book-modal') {
                 document.getElementById('cita-datetime').value = appointment.dateTime.toLocaleString(locale, formatOptions);
                 document.getElementById('client-name').value = '';
                 document.getElementById('client-email').value = '';
            }
            if (modalId === 'cancel-modal') document.getElementById('cancel-cita-datetime').value = appointment.dateTime.toLocaleString(locale, formatOptions);

        } else if (modalId === 'create-modal') {
            document.getElementById('create-form').reset();
            
            if (selectedSlotInfo && selectedSlotInfo.type === 'empty') {
                const selectedDate = new Date(selectedSlotInfo.datetime);
                const year = selectedDate.getFullYear();
                const month = (selectedDate.getMonth() + 1).toString().padStart(2, '0');
                const day = selectedDate.getDate().toString().padStart(2, '0');
                document.getElementById('new-date').value = `${year}-${month}-${day}`;

                const hour = selectedDate.getHours().toString().padStart(2, '0');
                document.getElementById('new-time-start').value = `${hour}:00`;
                document.getElementById('new-time-end').value = "";
            } else {
                document.getElementById('new-time-start').value = "";
                document.getElementById('new-time-end').value = "";
            }
        }
        modal.classList.remove('hidden');
    }

    function hideModal(modalId) {
        document.getElementById(modalId).classList.add('hidden');
        document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
        selectedSlotInfo = null;
        const bookBtn = document.getElementById('book-action-btn');
        const deleteBtn = document.getElementById('show-delete-modal-btn');
        if (bookBtn) bookBtn.disabled = true;
        if (deleteBtn) deleteBtn.disabled = true;
    }
    
    function renderMockInbox() {
        const inboxContainer = document.getElementById('inbox-container');
        if (!inboxContainer) return;

        const reservedAppointments = appointments.filter(a => a.state === 'reserved');
        if (reservedAppointments.length === 0) {
            inboxContainer.innerHTML = '<p>No hay citas reservadas para mostrar recordatorios.</p>';
            return;
        }

        let html = '';
        reservedAppointments.forEach(app => {
            const formattedDate = app.dateTime.toLocaleString(locale, { timeZone, dateStyle: 'full', timeStyle: 'short', hour12: false});
            html += `
                <div class="email-mock">
                    <p><strong>Para:</strong> ${app.client.name} (${app.client.email})</p>
                    <p><strong>Asunto:</strong> Recuerda tu cita con Mara Beauty Studio</p>
                    <hr>
                    <div class="email-body">
                        <p>¡Hola ${app.client.name}!</p>
                        <p>Recuerda que tienes una cita con nosotros para el <strong>${formattedDate}</strong>.</p>
                        <p>Si deseas cancelar, haz clic en el siguiente botón:</p><br>
                        <a href="index.html?cancel=${app.id}" class="btn btn-primary">Cancelar Cita</a>
                    </div>
                </div>
            `;
        });
        inboxContainer.innerHTML = html;
    }

    function initializeApp() {
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                if (document.getElementById('username').value === 'admin' && document.getElementById('password').value === '12345') {
                    window.location.href = 'dashboard.html';
                } else {
                    document.getElementById('login-error').classList.remove('hidden');
                }
            });
            return;
        }
        
        const inboxContainer = document.getElementById('inbox-container');
        if (inboxContainer) {
            renderMockInbox();
            return;
        }

        const calendarEl = document.getElementById('admin-calendar') || document.getElementById('client-calendar');
        if (!calendarEl) return;

        const isAdminPage = calendarEl.id === 'admin-calendar';
        const calendarId = calendarEl.id;

        document.getElementById('prev-week-btn').addEventListener('click', () => {
            if (currentWeek > 1) {
                currentWeek--;
                renderCalendar(calendarId, isAdminPage);
            }
        });

        document.getElementById('next-week-btn').addEventListener('click', () => {
            if (currentWeek < 52) {
                currentWeek++;
                renderCalendar(calendarId, isAdminPage);
            }
        });

        document.querySelectorAll('.close-btn, .btn-secondary[data-modal-id]').forEach(btn => {
            btn.addEventListener('click', () => hideModal(btn.dataset.modalId));
        });

        if (isAdminPage) {
            populateTimeSelectors(); 
            renderCalendar('admin-calendar', true);
            document.getElementById('show-create-modal-btn').addEventListener('click', () => showModal('create-modal'));
            document.getElementById('show-delete-modal-btn').addEventListener('click', () => {
                if(selectedSlotInfo && selectedSlotInfo.type === 'existing') showModal('delete-modal');
            });
            document.getElementById('logout-btn').addEventListener('click', () => { window.location.href = 'admin.html'; });
            
            const createForm = document.getElementById('create-form');
            createForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const date = document.getElementById('new-date').value;
                const startTime = document.getElementById('new-time-start').value;
                const endTime = document.getElementById('new-time-end').value;
                if (!date || !startTime || !endTime) {
                    showAlert('Debes seleccionar fecha y horas.', 'error', 'admin');
                    return;
                };
                const startDateTime = new Date(`${date}T${startTime}`);
                const endDateTime = new Date(`${date}T${endTime}`);
                for (let d = startDateTime; d < endDateTime; d.setHours(d.getHours() + 1)) {
                    let newId = appointments.length > 0 ? Math.max(...appointments.map(a => a.id)) + 1 : 1;
                    const newDateTime = new Date(d);
                    const conflict = appointments.some(a => a.dateTime.getTime() === newDateTime.getTime());
                    if(!conflict) {
                        appointments.push({ id: newId, dateTime: newDateTime, state: 'available', client: null });
                    }
                }
                hideModal('create-modal');
                renderCalendar('admin-calendar', true);
                showAlert('Nuevas citas disponibles creadas.', 'success', 'admin');
            });

            const confirmDeleteBtn = document.getElementById('confirm-delete-btn');
            confirmDeleteBtn.addEventListener('click', () => {
                if (!selectedSlotInfo || selectedSlotInfo.type !== 'existing') return;
                appointments = appointments.filter(a => a.id !== selectedSlotInfo.id);
                hideModal('delete-modal');
                renderCalendar('admin-calendar', true);
                showAlert('La cita ha sido eliminada.', 'success', 'admin');
            });

        } else { // Client Page
            renderCalendar('client-calendar', false);
            const urlParams = new URLSearchParams(window.location.search);
            const cancelId = urlParams.get('cancel');
            if (cancelId) {
                selectedSlotInfo = { id: parseInt(cancelId), type: 'existing' };
                showModal('cancel-modal');
            }
            document.getElementById('book-action-btn').addEventListener('click', () => {
                if(selectedSlotInfo && selectedSlotInfo.type === 'existing') showModal('book-modal');
            });

            const bookForm = document.getElementById('book-form');
            bookForm.addEventListener('submit', (e) => {
                e.preventDefault();
                if (!selectedSlotInfo || selectedSlotInfo.type !== 'existing') return;
                const name = document.getElementById('client-name').value;
                const email = document.getElementById('client-email').value;
                const appointment = appointments.find(a => a.id === selectedSlotInfo.id);
                if (appointment && appointment.state === 'available') {
                    appointment.state = 'reserved';
                    appointment.client = { name, email };
                    hideModal('book-modal');
                    renderCalendar('client-calendar', false);
                    showAlert('¡Cita reservada con éxito!', 'success', 'client');
                } else {
                    hideModal('book-modal');
                    renderCalendar('client-calendar', false);
                    showAlert('Error: La cita ya no está disponible.', 'error', 'client');
                }
            });

            const confirmCancelBtn = document.getElementById('confirm-cancel-btn');
            confirmCancelBtn.addEventListener('click', () => {
                if (!selectedSlotInfo || selectedSlotInfo.type !== 'existing') return;
                const appointment = appointments.find(a => a.id === selectedSlotInfo.id);
                if(appointment){
                    appointment.state = 'available';
                    appointment.client = null;
                    hideModal('cancel-modal');
                    renderCalendar('client-calendar', false);
                    showAlert('Tu cita ha sido cancelada.', 'success', 'client');
                }
            });
        }
    }

    initializeApp();
});